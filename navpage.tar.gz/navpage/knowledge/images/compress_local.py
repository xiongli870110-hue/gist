import os
import io
from PIL import Image, ImageChops

TARGET_KB = 300
MAX_SIDE = 1600
TRIM_TOL = 6
OUTPUT_FMT = "webp"  # 可改为 "jpeg"

def is_image_file(filename):
    return filename.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))

def trim_border(img, bg_color=(0, 0, 0, 0), tol=TRIM_TOL):
    if img.mode not in ("RGB", "RGBA"):
        img = img.convert("RGBA")
    bg = Image.new(img.mode, img.size, bg_color)
    diff = ImageChops.difference(img, bg)
    diff = ImageChops.add(diff, diff, scale=1.0, offset=-tol)
    bbox = diff.getbbox()
    return img.crop(bbox) if bbox else img

def scale_image(img, max_side=MAX_SIDE):
    w, h = img.size
    if max(w, h) <= max_side:
        return img
    ratio = max_side / max(w, h)
    return img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)

def compress_image(img, out_path, target_kb=TARGET_KB, fmt=OUTPUT_FMT):
    img = img.convert("RGB")
    for q in range(95, 39, -5):
        buf = io.BytesIO()
        img.save(buf, format=fmt.upper(), quality=q)
        size_kb = len(buf.getvalue()) / 1024
        if size_kb <= target_kb:
            with open(out_path, "wb") as f:
                f.write(buf.getvalue())
            return size_kb, q
    # 最后写入最小质量版本
    with open(out_path, "wb") as f:
        f.write(buf.getvalue())
    return size_kb, q

def process_images_in_current_dir():
    for filename in os.listdir("."):
        if not is_image_file(filename):
            continue
        try:
            img = Image.open(filename)
            img = trim_border(img)
            img = scale_image(img)
            name, _ = os.path.splitext(filename)
            out_file = f"{name}_min.{OUTPUT_FMT}"
            size_kb, q = compress_image(img, out_file)
            print(f"✅ {filename} → {out_file} | {round(size_kb,1)}KB | q={q}")
        except Exception as e:
            print(f"❌ {filename} 处理失败：{e}")

if __name__ == "__main__":
    process_images_in_current_dir()
