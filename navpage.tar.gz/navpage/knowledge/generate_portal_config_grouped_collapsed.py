import os
import json
import shutil

WORK_DIR = "."
OUTPUT_DIR = "."
EXCLUDED = {"index.html", "index.backup.html"}
# 新增：排除 icons 和 images 文件夹
EXCLUDED_DIRS = {"videos", "images"}
target_html = os.path.join(OUTPUT_DIR, "index.html")
backup_html = os.path.join(OUTPUT_DIR, "index.backup.html")
last_json = os.path.join(OUTPUT_DIR, "last_pages.json")

def format_name(filename):
    return os.path.splitext(filename)[0]

# 递归扫描目录并分组
groups = {}
for root, dirs, files in os.walk(WORK_DIR):
    rel_root = os.path.relpath(root, WORK_DIR)

    # 跳过 icons 和 images 文件夹及其子目录
    if any(part in EXCLUDED_DIRS for part in rel_root.split(os.sep)):
        continue

    group_name = "根目录" if rel_root == "." else rel_root
    html_files = [f for f in files if f.endswith(".html") and f not in EXCLUDED]
    if html_files:
        groups.setdefault(group_name, [])
        for f in sorted(html_files):
            filepath = os.path.join(rel_root, f) if rel_root != "." else f
            groups[group_name].append({
                "name": format_name(f),
                "file": filepath.replace("\\", "/")
            })

# 保存 last_pages.json
with open(last_json, "w", encoding="utf-8") as jf:
    json.dump(groups, jf, ensure_ascii=False, indent=2)

# 备份旧 index.html
if os.path.exists(target_html):
    shutil.copy2(target_html, backup_html)

# 构建 allGroups JS
lines = []
for group, pages in groups.items():
    page_lines = [f'        {{ name: "{p["name"]}", file: "{p["file"]}" }}' for p in pages]
    group_block = f'  "{group}": [\n' + ",\n".join(page_lines) + "\n  ]"
    lines.append(group_block)
all_groups_js = "const allGroups = {\n" + ",\n".join(lines) + "\n};"

# 生成 index.html（折叠版导航）
html = f"""<!DOCTYPE html>
<html lang="zh-CN" data-theme="dark">
<head>
  <meta charset="UTF-8" />
  <title>运维门户</title>
  <link rel="icon" href="../icons/favicon.ico" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    [data-theme="dark"] body {{
      background: linear-gradient(to bottom right, #4f46e5, #7c3aed);
      color: white;
    }}
    [data-theme="light"] body {{
      background: linear-gradient(to bottom right, #f9fafb, #e5e7eb);
      color: black;
    }}
    [data-theme="light"] .sidebar {{
      background-color: #ffffff;
      color: #111827;
    }}
    [data-theme="dark"] .sidebar {{
      background-color: rgba(255,255,255,0.1);
      color: white;
    }}
  </style>
</head>
<body class="min-h-screen flex">
  <aside class="sidebar w-64 p-4 space-y-4 shadow-lg overflow-y-auto">
    <h2 class="text-xl font-bold mb-4">页面导航</h2>
    <input type="text" id="search-box" placeholder="搜索页面..."
           class="w-full p-2 rounded bg-white text-black placeholder-gray-500 mb-3" oninput="filterPages()">
    <div id="grouped-list"></div>
    <button onclick="toggleTheme()" class="w-full bg-white/10 hover:bg-white/20 px-4 py-2 rounded transition">
      切换主题
    </button>
  </aside>

  <main class="flex-1 p-6">
    <iframe id="page-frame" class="w-full h-[90vh] border-none rounded-xl border-2 border-white/20 shadow-lg"></iframe>
  </main>

  <script>
    {all_groups_js}

    let pages = [];

    window.onload = function() {{
      renderGroupedList(allGroups);
      pages = Object.values(allGroups).flat();

      const last = localStorage.getItem("lastPage");
      if (last && pages.some(p => p.file === last)) {{
        loadPage(last);
      }} else if (pages.length > 0) {{
        loadPage(pages[0].file);
      }}
    }};

    function renderGroupedList(groups) {{
      const container = document.getElementById("grouped-list");
      container.innerHTML = "";
      for (const [group, list] of Object.entries(groups)) {{
        // 分组标题按钮
        const groupTitle = document.createElement("button");
        groupTitle.className = "w-full text-left font-bold mt-4 mb-2 px-2 py-1 rounded hover:bg-white/20";
        groupTitle.textContent = group;

        // 分组内容容器（默认折叠）
        const groupContainer = document.createElement("div");
        groupContainer.style.display = "none";

        list.forEach(page => {{
          const btn = document.createElement("button");
          btn.className = "w-full text-left px-2 py-1 rounded hover:bg-white/10";
          btn.textContent = page.name;
          btn.onclick = () => loadPage(page.file);
          groupContainer.appendChild(btn);
        }});

        // 点击标题切换展开/折叠
        groupTitle.onclick = () => {{
          groupContainer.style.display = groupContainer.style.display === "none" ? "block" : "none";
        }};

        container.appendChild(groupTitle);
        container.appendChild(groupContainer);
      }}
    }}

    function filterPages() {{
      const query = document.getElementById("search-box").value.toLowerCase();
      const filtered = pages.filter(page => page.name.toLowerCase().includes(query));
      const grouped = {{}};
      filtered.forEach(p => {{
        const group = Object.keys(allGroups).find(g =>
          allGroups[g].some(pg => pg.file === p.file)
        );
        if (!group) return;
        if (!grouped[group]) grouped[group] = [];
        grouped[group].push(p);
      }});
      renderGroupedList(grouped);

      // 自动展开有匹配结果的分组
      const container = document.getElementById("grouped-list");
      Array.from(container.children).forEach(el => {{
        if (el.tagName === "DIV") el.style.display = "block";
      }});
    }}

    function loadPage(file) {{
      const iframe = document.getElementById("page-frame");
      iframe.src = file;
      localStorage.setItem("lastPage", file);
      iframe.onerror = () => {{
        iframe.srcdoc = `<div style='padding:2em; text-align:center; font-size:1.2em; color:#f87171;'>
          页面加载失败：<strong>${{file}}</strong> 不存在或无法访问。
        </div>`;
      }};
    }}

    function toggleTheme() {{
      const html = document.documentElement;
      const current = html.getAttribute("data-theme");
      const next = current === "dark" ? "light" : "dark";
      html.setAttribute("data-theme", next);
      localStorage.setItem("theme", next);
    }}
  </script>
</body>
</html>
"""

with open(target_html, "w", encoding="utf-8") as f:
    f.write(html)

print("✅ index.html 已生成（折叠版分组导航，排除 icons 和 images 文件夹）")
print(f"📦 分组数：{len(groups)}")
print("💾 已保存：last_pages.json 和 index.backup.html")
