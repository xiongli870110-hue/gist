#!/tmp/venv/bin/python3
import yaml
from pathlib import Path
import os

# 替换文件并保持权限和属主 generate_nav.py
# rm /tmp/navpage/generate_nav.py.txt
# nano /tmp/navpage/generate_nav.py.txt
# cat /tmp/navpage/generate_nav.py.txt | tee /tmp/navpage/generate_nav.py > /dev/null
# 单次测试.py代码：su - appuser -c "/tmp/venv/bin/python3 /tmp/navpage/generate_nav.py"

# 替换文件并保持权限和属主 conf.yml
# rm /tmp/navpage/conf.yml.txt
# nano /tmp/navpage/conf.yml.txt
# cat /tmp/navpage/conf.yml.txt | tee /tmp/navpage/conf.yml > /dev/null

# 工作目录
WORK_DIR = Path("/tmp/navpage")
CONFIG_PATH = WORK_DIR / "conf.yml"

TEMPLATE_HEAD = """<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="UTF-8">
  <title>{title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    :root {{
      --card-min-width: 180px;
      --card-padding: 0.6rem;
      --card-radius: 8px;
      --card-gap: 0.8rem;
      --card-title-size: 0.95rem;
      --card-desc-size: 0.82rem;
      --icon-size: 14px;
      --card-shadow: 0 1px 4px rgba(0,0,0,0.06);
    }}
    body {{ font-family: sans-serif; margin: 0; background: #f4f6f9; color: #333; }}
    header {{ background: #2563eb; color: white; padding: 0.8rem 1.2rem; }}
    header h1 {{ margin: 0; font-size: 1.2rem; }}
    .container {{ max-width: 1100px; margin: auto; padding: 1.2rem; }}
    h2 {{ border-bottom: 2px solid #e5e7eb; padding-bottom: 0.4rem; margin-top: 1.4rem; font-size: 1.1rem; }}
    .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(var(--card-min-width), 1fr)); gap: var(--card-gap); margin-top: 0.9rem; }}
    .card {{ background: white; border-radius: var(--card-radius); padding: var(--card-padding); box-shadow: var(--card-shadow); transition: transform 0.15s, box-shadow 0.15s; }}
    .card:hover {{ transform: translateY(-3px); box-shadow: 0 4px 10px rgba(0,0,0,0.08); }}
    .card a {{ text-decoration: none; color: inherit; display: block; }}
    .card-title {{ display: flex; align-items: center; font-weight: 600; margin-bottom: 0.4rem; font-size: var(--card-title-size); }}
    .card-title img {{ width: var(--icon-size); height: var(--icon-size); margin-right: 0.4rem; object-fit: contain; border-radius: 3px; }}
    .card-desc {{ font-size: var(--card-desc-size); color: #666; line-height: 1.2; max-height: 3.6em; overflow: hidden; text-overflow: ellipsis; }}
    @media (max-width: 480px) {{
      :root {{
        --card-min-width: 140px;
        --card-padding: 0.5rem;
        --icon-size: 12px;
        --card-title-size: 0.95rem;
        --card-desc-size: 0.78rem;
      }}
    }}
  </style>
</head>
<body>
<header><h1>{title}</h1></header>
<div class="container">
"""

TEMPLATE_FOOT = """
</div>
</body>
</html>
"""

def generate_html(config):
    parts = [TEMPLATE_HEAD.format(title=config.get("title", "导航页面"))]
    for group in config.get("groups", []):
        parts.append(f"<h2>{group['name']}</h2>")
        parts.append('<div class="grid">')
        for link in group.get("links", []):
            icon = link.get('icon', '')
            icon_html = f'<img src="{icon}" alt="icon">' if icon else '<span style="display:inline-block;width:var(--icon-size);height:var(--icon-size);margin-right:0.4rem;"></span>'
            parts.append(f"""
            <div class="card">
              <a href="{link['url']}" target="_blank" rel="noopener noreferrer">
                <div class="card-title">
                  {icon_html}{link['name']}
                </div>
                <div class="card-desc">{link.get('desc', '')}</div>
              </a>
            </div>
            """)
        parts.append('</div>')
    parts.append(TEMPLATE_FOOT)
    return "\n".join(parts)

if __name__ == "__main__":
    print("🔧 正在生成导航页面...")

    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"未找到配置文件: {CONFIG_PATH}")
    
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)
    
    html = generate_html(config)
    output_file = WORK_DIR / "nav.html"
    output_file.write_text(html, encoding="utf-8")

    try:
        uid = os.getpwnam("appuser").pw_uid
        gid = os.getpwnam("appuser").pw_gid
        os.chown(output_file, uid, gid)
        os.chmod(output_file, 0o644)
    except Exception:
        pass

    print(f"✅ 已生成 {output_file}")
