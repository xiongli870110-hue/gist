import os
import re
import json
import shutil

# === 配置项 ===
WORK_DIR = "/tmp/navpage/private_html"     # 扫描 HTML 页面文件的目录
OUTPUT_DIR = "/tmp/navpage/private_html"   # 输出 index.html 和记录文件的目录

backup_html = os.path.join(OUTPUT_DIR, "index.backup.html")
target_html = os.path.join(OUTPUT_DIR, "index.html")
page_record = os.path.join(OUTPUT_DIR, "last_pages.json")
excluded_file = "index.html"
target_user = "li"
admin_user = "admin"

# === 图标关键词映射 ===
icon_map = {
    "nginx": "fa-server",
    "dashboard": "fa-tachometer-alt",
    "certbot": "fa-certificate",
    "portainer": "fa-boxes",
    "cert": "fa-shield-halved",
    "install": "fa-download",
    "translate": "fa-language",
    "doc": "fa-file-alt",
    "log": "fa-file-lines",
    "config": "fa-sliders",
    "extra": "fa-puzzle-piece",
    "default": "fa-file"
}

def guess_icon(filename):
    for key in icon_map:
        if key in filename.lower():
            return icon_map[key]
    return icon_map["default"]

def normalize_key(filename):
    name = os.path.splitext(filename)[0]
    return re.sub(r"[^\w]", "_", name).lower()

def format_name(filename):
    return os.path.splitext(filename)[0]

# === 初始化备份（仅首次执行）===
if not os.path.exists(backup_html):
    print("📦 首次执行：创建 index.backup.html 作为模板备份")
    shutil.copyfile(target_html, backup_html)
else:
    print("✅ 已检测到 index.backup.html，跳过备份创建")

# === 获取当前页面列表（排除 index.html）===
html_files = sorted(
    f for f in os.listdir(WORK_DIR)
    if f.endswith(".html") and f != excluded_file
)

# === 加载上次页面记录 ===
last_pages = []
if os.path.exists(page_record):
    with open(page_record, "r", encoding="utf-8") as f:
        last_pages = json.load(f)

# === 如果页面列表无变化，跳过更新 ===
if html_files == last_pages:
    print("✅ 页面未变动，index.html 保持不变")
    exit(0)

# === 页面有变动，开始更新 ===
print("🔄 页面变动检测到，开始重新生成 index.html")

# === 构建 allPages 和用户页面列表 ===
all_pages = {}
li_pages = []
admin_pages = []

for f in html_files:
    key = normalize_key(f)
    all_pages[key] = {
        "name": format_name(f),
        "file": f,
        "icon": guess_icon(f)
    }
    li_pages.append(key)
    admin_pages.append(key)

# === 构建 allPages JS 片段 ===
all_pages_js = "const allPages = {\n"
for key, val in all_pages.items():
    all_pages_js += f'  {key}: {{ name: "{val["name"]}", file: "{val["file"]}", icon: "{val["icon"]}" }},\n'
all_pages_js += "};"

# === 构建 users JS 片段 ===
admin_pages_str = "".join(f'      "{key}",\n' for key in admin_pages)
li_pages_str = "".join(f'      "{key}",\n' for key in li_pages)

users_js = (
    "const users = {\n"
    f"  {admin_user}: {{\n"
    '    password: "admin123",\n'
    "    pages: [\n"
    f"{admin_pages_str}    ]\n"
    "  },\n"
    f"  {target_user}: {{\n"
    '    password: "nginxlover",\n'
    "    pages: [\n"
    f"{li_pages_str}    ]\n"
    "  },\n"
    "  guest: {\n"
    '    password: "readonly",\n'
    '    pages: ["dashboard"]\n'
    "  }\n"
    "};"
)

# === 从备份读取模板 ===
with open(backup_html, "r", encoding="utf-8") as f:
    html = f.read()

# === 替换 const allPages ===
html = re.sub(r"const allPages = \{.*?\};", all_pages_js, html, flags=re.DOTALL)

# === 替换 const users ===
html = re.sub(r"const users = \{.*?\};", users_js, html, flags=re.DOTALL)

# === 写入 index.html ===
with open(target_html, "w", encoding="utf-8") as f:
    f.write(html)

# === 更新页面记录 ===
with open(page_record, "w", encoding="utf-8") as f:
    json.dump(html_files, f, ensure_ascii=False, indent=2)

print("✅ index.html 已更新（基于备份模板）")
print("📦 页面列表已记录到 last_pages.json")
