import os
import sys
import requests
import base64
import datetime
import subprocess

# === 配置项 ===
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "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")
REPO_OWNER = "xiongli870110-hue"
REPO_NAME = "wine"
BRANCH = "main"
SUBDIR = "private_html"
DEST_DIR = f"/tmp/navpage/{SUBDIR}"
LOG_DIR = "/tmp/logs"
LOG_FILE = f"{LOG_DIR}/download_from_github_private_html.log"

# === 创建目录 ===
os.makedirs(DEST_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

def log(msg):
    print(msg)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(msg + "\n")

log(f"📁 目标目录：{DEST_DIR}")
log("🔐 使用私有仓库访问令牌")
log("----------------------------")

# === 初始化计数器 ===
success_count = 0
fail_count = 0

# === 获取目录文件列表 ===
api_url = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{SUBDIR}?ref={BRANCH}"
log(f"📡 正在获取目录列表：{SUBDIR}")
log(f"🔗 API：{api_url}")

headers = {
    "Authorization": f"token {GITHUB_TOKEN}",
    "Accept": "application/vnd.github.v3+json"
}

response = requests.get(api_url, headers=headers)
if response.status_code != 200:
    log("❌ 未找到任何文件，或目录访问失败。")
    sys.exit(1)

file_paths = [item["path"] for item in response.json() if item["type"] == "file"]

# === 遍历并下载每个文件 ===
for file_path in file_paths:
    file_name = os.path.basename(file_path)
    file_api = f"https://api.github.com/repos/{REPO_OWNER}/{REPO_NAME}/contents/{file_path}?ref={BRANCH}"
    log(f"📥 正在下载：{file_path}")
    log(f"🔗 API：{file_api}")

    file_response = requests.get(file_api, headers=headers)
    if file_response.status_code == 200:
        content = file_response.json().get("content")
        if content:
            decoded = base64.b64decode(content)
            with open(os.path.join(DEST_DIR, file_name), "wb") as f:
                f.write(decoded)
            log(f"✅ 下载成功：{file_name}")
            success_count += 1
        else:
            log(f"❌ 下载失败或内容为空：{file_name}")
            fail_count += 1
    else:
        log(f"❌ 下载失败：{file_name}")
        fail_count += 1
    log("----------------------------")

# === 写入统计信息和时间戳 ===
log("📊 下载统计：")
log(f"✅ 成功：{success_count}")
log(f"❌ 失败：{fail_count}")
log(f"🕒 执行完成时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

# === 修复权限（可选）===
if os.path.isdir(DEST_DIR):
    log(f"[INFO] Changing ownership of {DEST_DIR} to appuser:appuser")
    subprocess.run(["chown", "-R", "appuser:appuser", DEST_DIR], stdout=subprocess.DEVNULL)
    log(f"[INFO] Making *.py files executable in {DEST_DIR}")
    subprocess.run(["find", DEST_DIR, "-maxdepth", "1", "-name", "*.py", "-exec", "chmod", "+x", "{}", ";"], stdout=subprocess.DEVNULL)
else:
    log(f"[WARN] Target directory {DEST_DIR} does not exist")

# === 执行指定 .py 文件列表（如果存在）===
gen_scripts = [
    # os.path.join(DEST_DIR, "generate_portal_config_pinyin.py"),
    os.path.join(DEST_DIR, "generate_portal_config_mulu.py"),
    # os.path.join(DEST_DIR, "rss_news.py"),
    os.path.join(DEST_DIR, "generate_nav.py"),
]

for script in gen_scripts:
    if os.path.isfile(script):
        log(f"🚀 执行生成脚本：{script}")
        subprocess.run(["python3", script], stdout=open(LOG_FILE, "a"), stderr=subprocess.STDOUT)
    else:
        log(f"⚠️ 未找到生成脚本：{script}，跳过执行")
