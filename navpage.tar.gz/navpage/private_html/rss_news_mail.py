import feedparser
import requests
import time
from bs4 import BeautifulSoup
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

# 配置
RSS_URL = "https://bloombergnew.buzzing.cc/feed.xml"

# 从环境变量获取邮箱信息（在 .sh 中设置）
SENDER_EMAIL = os.getenv("SENDER_EMAIL")
SENDER_PASSWORD = os.getenv("SENDER_PASSWORD")
RECEIVER_EMAIL = os.getenv("RECEIVER_EMAIL")

if not all([SENDER_EMAIL, SENDER_PASSWORD, RECEIVER_EMAIL]):
    raise RuntimeError("SENDER_EMAIL, SENDER_PASSWORD 或 RECEIVER_EMAIL 未设置！请在 shell 中导出环境变量。")

def check_url_accessible(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0'
        }
        response = requests.head(url, headers=headers, timeout=10, allow_redirects=True)
        return response.status_code == 200
    except requests.RequestException as e:
        print(f"无法访问 URL {url}: {e}")
        return False

def extract_article_content(url):
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        paragraphs = soup.find_all('p')
        content = ' '.join([para.get_text(strip=True) for para in paragraphs if para.get_text(strip=True)])
        return content[:1000] + "..." if len(content) > 1000 else content or "无法提取正文内容"
    except Exception as e:
        return f"提取正文失败：{e}"

def send_email(subject, body):
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = RECEIVER_EMAIL
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.sendmail(SENDER_EMAIL, RECEIVER_EMAIL, msg.as_string())
        server.close()
        print("邮件已成功发送！")
    except Exception as e:
        print(f"邮件发送失败: {e}")

def fetch_rss_and_send_email(max_retries=3, retry_delay=5):
    for attempt in range(max_retries):
        try:
            if not check_url_accessible(RSS_URL):
                print(f"错误：无法访问 RSS 提要 URL {RSS_URL}")
                return
            feed = feedparser.parse(RSS_URL)
            if feed.bozo:
                print(f"错误：无法解析 RSS 提要，原因：{feed.bozo_exception}")
                return
            entries = feed.entries[:10]
            if not entries:
                print("没有获取到消息（可能是提要为空或受限制）")
                return

            body = "=== 彭博社最新十条消息 ===\n\n"
            for i, entry in enumerate(entries, 1):
                body += f"{i}. 标题: {entry.get('title', '无标题')}\n"
                body += f"链接: {entry.get('link', '无链接')}\n"
                body += f"发布时间: {entry.get('published', '未知时间')}\n"
                body += f"摘要: {entry.get('summary', '无内容')}\n"
                # 可选正文
                # content = extract_article_content(entry.get('link', ''))
                # body += f"正文: {content}\n"
                body += "-" * 50 + "\n"

            current_date = datetime.now().strftime("%Y年%m月%d日新闻")
            send_email(current_date, body)
            return
        except Exception as e:
            print(f"尝试 {attempt + 1}/{max_retries} 失败: {e}")
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
            continue
    print(f"错误：在 {max_retries} 次尝试后仍无法获取 RSS 提要")

if __name__ == "__main__":
    fetch_rss_and_send_email()
